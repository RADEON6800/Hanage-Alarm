# このモジュール用の ProGuard / R8 ルール。
# release ビルドで難読化する場合はここにルールを追加してください（今回は minifyEnabled false のため未使用）。
