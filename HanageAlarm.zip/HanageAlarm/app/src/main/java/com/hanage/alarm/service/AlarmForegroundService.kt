package com.hanage.alarm.service

import android.app.AlarmManager
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import com.hanage.alarm.HanageApp
import com.hanage.alarm.R
import com.hanage.alarm.data.Alarm
import com.hanage.alarm.data.AlarmRepository
import com.hanage.alarm.data.DismissMode
import com.hanage.alarm.receiver.AlarmReceiver
import com.hanage.alarm.sensor.ShakeDetector
import com.hanage.alarm.ui.AlarmRingActivity
import com.hanage.alarm.util.AlarmScheduler
import com.hanage.alarm.util.VolumeLockManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class AlarmForegroundService : Service() {

    private lateinit var prefs: SharedPreferences
    private val serviceScope = CoroutineScope(Dispatchers.IO + Job())

    private var mediaPlayer: MediaPlayer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var volumeLockManager: VolumeLockManager? = null
    private var shakeDetector: ShakeDetector? = null

    private var currentAlarm: Alarm? = null
    /** BOTH モード時、計算問題が解けたかどうか（解けていればシェイク段階に進んでいる） */
    private var mathStageCleared = false

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        val alarmIdFromIntent = intent?.getLongExtra(AlarmScheduler.EXTRA_ALARM_ID, -1L) ?: -1L

        when (action) {
            ACTION_RING -> startRinging(alarmIdFromIntent)
            ACTION_MATH_SOLVED -> onMathSolved()
            ACTION_STOP -> stopRinging()
            null -> {
                // システムに殺された後、START_STICKY により intent=null で再起動されたケース。
                // 直前まで鳴動していたアラームIDを復元して鳴動を再開する。
                val savedId = prefs.getLong(KEY_RINGING_ALARM_ID, -1L)
                if (savedId != -1L) startRinging(savedId) else stopSelf()
            }
        }
        return START_STICKY
    }

    private fun startRinging(alarmId: Long) {
        if (alarmId == -1L) {
            stopSelf()
            return
        }
        prefs.edit().putLong(KEY_RINGING_ALARM_ID, alarmId).apply()

        // フォアグラウンド昇格は即座に行う（5〜10秒以内という制約があるため詳細情報を待たない）
        startForeground(NOTIF_ID, buildNotification(alarmId))

        serviceScope.launch {
            val repository = AlarmRepository(applicationContext)
            val alarm = repository.getById(alarmId) ?: return@launch
            currentAlarm = alarm
            mathStageCleared = false

            acquireWakeLock()
            startPlayback(alarm)
            volumeLockManager = VolumeLockManager(applicationContext).also { it.lock() }
            maybeStartShake(alarm)
            launchRingActivity(alarm)
        }
    }

    private fun launchRingActivity(alarm: Alarm) {
        val intent = Intent(applicationContext, AlarmRingActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            putExtra(AlarmScheduler.EXTRA_ALARM_ID, alarm.id)
        }
        try {
            startActivity(intent)
        } catch (_: Exception) {
            // 一部端末ではバックグラウンドからの直接起動が拒否される場合がある。
            // その場合は通知の fullScreenIntent がロック画面上への表示をフォールバックとして担う。
        }
    }

    private fun startPlayback(alarm: Alarm) {
        val uri = resolveSoundUri(alarm)
        mediaPlayer?.release()
        mediaPlayer = MediaPlayer().apply {
            try {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setDataSource(applicationContext, uri)
                isLooping = true
                prepare()
                start()
            } catch (e: Exception) {
                // カスタム音源の権限切れ等で再生できない場合はプリセットにフォールバック
                try {
                    reset()
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    setDataSource(applicationContext, presetSoundUri())
                    isLooping = true
                    prepare()
                    start()
                } catch (_: Exception) { /* 再生自体を諦める（バイブ・画面表示は継続） */ }
            }
        }
    }

    private fun resolveSoundUri(alarm: Alarm): Uri =
        if (alarm.soundUri == Alarm.PRESET_DISSONANCE_URI) presetSoundUri() else Uri.parse(alarm.soundUri)

    private fun presetSoundUri(): Uri =
        Uri.parse("android.resource://$packageName/${R.raw.alarm_preset_dissonance}")

    private fun maybeStartShake(alarm: Alarm) {
        val needsShakeNow = when (alarm.dismissMode) {
            DismissMode.SHAKE -> true
            DismissMode.BOTH -> mathStageCleared
            DismissMode.MATH -> false
        }
        if (!needsShakeNow) return

        shakeDetector?.stop()
        shakeDetector = ShakeDetector(
            context = applicationContext,
            onCountChanged = { count -> broadcastShakeCount(count, alarm.shakeThreshold) },
            onThresholdReached = { stopRinging() },
            threshold = alarm.shakeThreshold
        ).also { it.start() }
    }

    private fun broadcastShakeCount(count: Int, threshold: Int) {
        val intent = Intent(ACTION_SHAKE_UPDATE).apply {
            setPackage(packageName)
            putExtra(EXTRA_SHAKE_COUNT, count)
            putExtra(EXTRA_SHAKE_THRESHOLD, threshold)
        }
        sendBroadcast(intent)
    }

    /** AlarmRingActivity から「計算問題に正解した」と通知された時に呼ばれる */
    private fun onMathSolved() {
        val alarm = currentAlarm ?: return
        if (alarm.dismissMode == DismissMode.BOTH) {
            mathStageCleared = true
            maybeStartShake(alarm)
        } else {
            stopRinging()
        }
    }

    private fun stopRinging() {
        prefs.edit().remove(KEY_RINGING_ALARM_ID).apply()

        shakeDetector?.stop()
        shakeDetector = null

        mediaPlayer?.let {
            try { it.stop() } catch (_: Exception) { }
            it.release()
        }
        mediaPlayer = null

        volumeLockManager?.unlock()
        volumeLockManager = null

        releaseWakeLock()

        // 次回に備えて繰り返しなしアラームは無効化し、繰り返しアラームは次回分を再スケジュールする
        currentAlarm?.let { alarm ->
            serviceScope.launch {
                val repository = AlarmRepository(applicationContext)
                if (alarm.hasAnyRepeatDay()) {
                    AlarmScheduler.schedule(applicationContext, alarm)
                } else {
                    repository.update(alarm.copy(enabled = false))
                }
            }
        }
        currentAlarm = null

        val stopActivityIntent = Intent(AlarmRingActivity.ACTION_FINISH).apply { setPackage(packageName) }
        sendBroadcast(stopActivityIntent)

        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        // タスクキル（最近使ったアプリからのスワイプ）された際、まだ鳴動中であれば
        // AlarmManager 経由で即座に自分自身（AlarmReceiver）を再起動し、鳴動を継続させる。
        val ringingId = prefs.getLong(KEY_RINGING_ALARM_ID, -1L)
        if (ringingId != -1L) {
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val restartIntent = Intent(applicationContext, AlarmReceiver::class.java).apply {
                action = AlarmScheduler.ACTION_RING
                putExtra(AlarmScheduler.EXTRA_ALARM_ID, ringingId)
            }
            val pi = PendingIntent.getBroadcast(
                applicationContext, RESTART_REQUEST_CODE, restartIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            am.setExactAndAllowWhileIdle(
                AlarmManager.ELAPSED_REALTIME_WAKEUP,
                SystemClock.elapsedRealtime() + 500,
                pi
            )
        }
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "HanageAlarm:RingWakeLock"
        ).apply { acquire(10 * 60 * 1000L /*最大10分の保険*/) }
    }

    private fun releaseWakeLock() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    private fun buildNotification(alarmId: Long): Notification {
        val fullScreenIntent = Intent(applicationContext, AlarmRingActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            putExtra(AlarmScheduler.EXTRA_ALARM_ID, alarmId)
        }
        val fullScreenPendingIntent = PendingIntent.getActivity(
            applicationContext, alarmId.toInt(), fullScreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(applicationContext, HanageApp.CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(getString(R.string.notif_ringing_title))
            .setContentText(getString(R.string.notif_ringing_text))
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .setContentIntent(fullScreenPendingIntent)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.launch { }.cancel()
    }

    companion object {
        const val ACTION_RING = "com.hanage.alarm.action.SERVICE_RING"
        const val ACTION_STOP = "com.hanage.alarm.action.SERVICE_STOP"
        const val ACTION_MATH_SOLVED = "com.hanage.alarm.action.MATH_SOLVED"
        const val ACTION_SHAKE_UPDATE = "com.hanage.alarm.action.SHAKE_UPDATE"
        const val EXTRA_SHAKE_COUNT = "extra_shake_count"
        const val EXTRA_SHAKE_THRESHOLD = "extra_shake_threshold"

        private const val PREFS_NAME = "hanage_alarm_service_prefs"
        private const val KEY_RINGING_ALARM_ID = "ringing_alarm_id"
        private const val NOTIF_ID = 42
        private const val RESTART_REQUEST_CODE = 9911

        fun stopIntent(context: Context): Intent =
            Intent(context, AlarmForegroundService::class.java).apply { action = ACTION_STOP }

        fun mathSolvedIntent(context: Context): Intent =
            Intent(context, AlarmForegroundService::class.java).apply { action = ACTION_MATH_SOLVED }
    }
}
