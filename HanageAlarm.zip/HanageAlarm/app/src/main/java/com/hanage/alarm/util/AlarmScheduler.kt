package com.hanage.alarm.util

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.hanage.alarm.data.Alarm
import com.hanage.alarm.receiver.AlarmReceiver
import com.hanage.alarm.ui.MainActivity
import java.util.Calendar

object AlarmScheduler {

    const val EXTRA_ALARM_ID = "extra_alarm_id"
    const val ACTION_RING = "com.hanage.alarm.action.RING"

    fun schedule(context: Context, alarm: Alarm) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val triggerAt = nextTriggerMillis(alarm)

        val ringIntent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_RING
            putExtra(EXTRA_ALARM_ID, alarm.id)
        }
        val operation = PendingIntent.getBroadcast(
            context, alarm.id.toInt(), ringIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val showIntent = Intent(context, MainActivity::class.java)
        val showPendingIntent = PendingIntent.getActivity(
            context, alarm.id.toInt(), showIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // setAlarmClock() は「ユーザー向けアラーム時計」として扱われ、Doze/スリープの影響を受けにくく、
        // ステータスバーにもアラームアイコンが表示される。
        am.setAlarmClock(AlarmManager.AlarmClockInfo(triggerAt, showPendingIntent), operation)
    }

    fun cancel(context: Context, alarm: Alarm) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val ringIntent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_RING
        }
        val operation = PendingIntent.getBroadcast(
            context, alarm.id.toInt(), ringIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.cancel(operation)
    }

    /** 次に鳴る時刻(ms)を計算する。繰り返し曜日が無い場合は「次に来るその時刻」一回のみ。 */
    fun nextTriggerMillis(alarm: Alarm): Long {
        val now = Calendar.getInstance()
        val candidate = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, alarm.hour)
            set(Calendar.MINUTE, alarm.minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        if (!alarm.hasAnyRepeatDay()) {
            if (candidate.timeInMillis <= now.timeInMillis) {
                candidate.add(Calendar.DAY_OF_YEAR, 1)
            }
            return candidate.timeInMillis
        }

        for (i in 0..7) {
            val c = candidate.clone() as Calendar
            c.add(Calendar.DAY_OF_YEAR, i)
            val dow = c.get(Calendar.DAY_OF_WEEK)
            if (alarm.isRepeatingOn(dow) && c.timeInMillis > now.timeInMillis) {
                return c.timeInMillis
            }
        }
        // 理論上ここには来ないが、フォールバックとして翌日同時刻
        candidate.add(Calendar.DAY_OF_YEAR, 1)
        return candidate.timeInMillis
    }
}
