package com.hanage.alarm.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.hanage.alarm.data.Alarm
import com.hanage.alarm.data.AlarmRepository
import com.hanage.alarm.databinding.ActivityMainBinding
import com.hanage.alarm.util.AlarmScheduler
import com.hanage.alarm.util.PermissionHelper
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var repository: AlarmRepository
    private lateinit var adapter: AlarmListAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        repository = AlarmRepository(applicationContext)

        adapter = AlarmListAdapter(
            onClick = { alarm -> openEditor(alarm.id) },
            onToggle = { alarm, checked -> onToggleAlarm(alarm, checked) },
            onLongClick = { alarm -> confirmDelete(alarm) }
        )
        binding.recyclerAlarms.layoutManager = LinearLayoutManager(this)
        binding.recyclerAlarms.adapter = adapter

        binding.fabAdd.setOnClickListener { openEditor(null) }

        lifecycleScope.launch {
            repository.observeAlarms().collect { list ->
                adapter.submitList(list)
                binding.textEmpty.visibility = if (list.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val onboardingDone = prefs.getBoolean(KEY_ONBOARDING_DONE, false)
        val allGranted = PermissionHelper.hasNotificationPermission(this) &&
            PermissionHelper.hasExactAlarmPermission(this)
        if (!onboardingDone || !allGranted) {
            startActivity(Intent(this, OnboardingActivity::class.java))
        }
    }

    private fun openEditor(alarmId: Long?) {
        val intent = Intent(this, EditAlarmActivity::class.java)
        if (alarmId != null) intent.putExtra(EditAlarmActivity.EXTRA_ALARM_ID, alarmId)
        startActivity(intent)
    }

    private fun onToggleAlarm(alarm: Alarm, checked: Boolean) {
        lifecycleScope.launch {
            val updated = alarm.copy(enabled = checked)
            repository.update(updated)
            if (checked) {
                AlarmScheduler.schedule(applicationContext, updated)
            } else {
                AlarmScheduler.cancel(applicationContext, updated)
            }
        }
    }

    private fun confirmDelete(alarm: Alarm) {
        MaterialAlertDialogBuilder(this)
            .setTitle(alarm.label.ifBlank { "アラーム" })
            .setMessage("このアラームを削除しますか？")
            .setPositiveButton(getString(com.hanage.alarm.R.string.delete)) { _, _ ->
                lifecycleScope.launch {
                    AlarmScheduler.cancel(applicationContext, alarm)
                    repository.delete(alarm)
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    companion object {
        const val PREFS_NAME = "hanage_main_prefs"
        const val KEY_ONBOARDING_DONE = "onboarding_done"
    }
}
