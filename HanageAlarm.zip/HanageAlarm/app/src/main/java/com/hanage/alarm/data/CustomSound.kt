package com.hanage.alarm.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * ユーザーが SAF (Storage Access Framework) 経由で追加した
 * カスタムアラーム音（wav / mp3 / opus / flac 等）。
 * uri は永続化パーミッションを取得済みの content:// URI 文字列。
 */
@Entity(tableName = "custom_sounds")
data class CustomSound(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val uri: String,
    val displayName: String
)
