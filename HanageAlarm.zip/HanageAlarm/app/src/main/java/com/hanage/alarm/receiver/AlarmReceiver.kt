package com.hanage.alarm.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.hanage.alarm.service.AlarmForegroundService
import com.hanage.alarm.util.AlarmScheduler

/**
 * AlarmManager.setAlarmClock() から呼び出される BroadcastReceiver。
 * AlarmManager 経由での起動はバックグラウンド起動制限の対象外のため、
 * ここから確実にフォアグラウンドサービスを開始できる。
 */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val alarmId = intent.getLongExtra(AlarmScheduler.EXTRA_ALARM_ID, -1L)
        if (alarmId == -1L) return

        val serviceIntent = Intent(context, AlarmForegroundService::class.java).apply {
            action = AlarmForegroundService.ACTION_RING
            putExtra(AlarmScheduler.EXTRA_ALARM_ID, alarmId)
        }
        ContextCompat.startForegroundService(context, serviceIntent)
    }
}
