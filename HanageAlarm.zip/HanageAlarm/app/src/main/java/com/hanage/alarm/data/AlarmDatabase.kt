package com.hanage.alarm.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters

@Database(entities = [Alarm::class, CustomSound::class], version = 1, exportSchema = false)
@TypeConverters(Converters::class)
abstract class AlarmDatabase : RoomDatabase() {
    abstract fun alarmDao(): AlarmDao
    abstract fun customSoundDao(): CustomSoundDao

    companion object {
        @Volatile private var INSTANCE: AlarmDatabase? = null

        fun getInstance(context: Context): AlarmDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AlarmDatabase::class.java,
                    "hanage_alarm.db"
                ).build().also { INSTANCE = it }
            }
    }
}

class Converters {
    @TypeConverter
    fun fromDismissMode(mode: DismissMode): String = mode.name

    @TypeConverter
    fun toDismissMode(value: String): DismissMode = DismissMode.valueOf(value)
}
