package com.hanage.alarm.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Calendar

/**
 * 1件のアラームを表すエンティティ。
 *
 * @param daysOfWeekMask Calendar.SUNDAY(1)〜Calendar.SATURDAY(7) に対応するビットマスク。
 *                       0 の場合は「繰り返しなし」＝次回発火後に自動で enabled=false になる単発アラーム。
 * @param soundUri       "preset:dissonance" ならプリセットの不協和音、それ以外は content:// の URI 文字列。
 * @param shakeThreshold シェイク解除に必要なカウント数（デフォルト30、ユーザーが自由に変更可能）。
 */
@Entity(tableName = "alarms")
data class Alarm(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val hour: Int,
    val minute: Int,
    val daysOfWeekMask: Int = 0,
    val enabled: Boolean = true,
    val label: String = "",
    val soundUri: String = PRESET_DISSONANCE_URI,
    val dismissMode: DismissMode = DismissMode.MATH,
    val shakeThreshold: Int = 30
) {
    fun isRepeatingOn(dayOfWeek: Int): Boolean = (daysOfWeekMask and (1 shl dayOfWeek)) != 0

    fun hasAnyRepeatDay(): Boolean = daysOfWeekMask != 0

    companion object {
        const val PRESET_DISSONANCE_URI = "preset:dissonance"

        fun maskOf(days: Set<Int>): Int {
            var mask = 0
            for (d in days) mask = mask or (1 shl d)
            return mask
        }

        fun daysFromMask(mask: Int): Set<Int> {
            val set = mutableSetOf<Int>()
            for (d in Calendar.SUNDAY..Calendar.SATURDAY) {
                if ((mask and (1 shl d)) != 0) set.add(d)
            }
            return set
        }
    }
}
