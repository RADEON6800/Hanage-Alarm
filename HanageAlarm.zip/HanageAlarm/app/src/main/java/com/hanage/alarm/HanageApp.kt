package com.hanage.alarm

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import com.google.android.material.color.DynamicColors

class HanageApp : Application() {

    override fun onCreate() {
        super.onCreate()

        // Android 12+ の場合、壁紙由来の Material You カラーを全アクティビティに自動適用する
        DynamicColors.applyToActivitiesIfAvailable(this)

        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = getString(R.string.notif_channel_desc)
                setBypassDnd(true)
                enableVibration(true)
                // アラーム音自体は MediaPlayer(STREAM_ALARM) 側で再生するため、通知チャンネル自体の音は鳴らさない
                setSound(null, null)
            }
            manager.createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_ID = "hanage_alarm_channel"
    }
}
