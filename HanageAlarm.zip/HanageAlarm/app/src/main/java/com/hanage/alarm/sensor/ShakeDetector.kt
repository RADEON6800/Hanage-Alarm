package com.hanage.alarm.sensor

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.abs

/**
 * x, y, z いずれかの軸の加速度が THRESHOLD_MS2 (70 m/s^2) を超えるたびに 1 カウントする。
 * 同じ振り動作を連続サンプリングで二重カウントしないよう、カウント間に不応期を設ける。
 */
class ShakeDetector(
    context: Context,
    private val onCountChanged: (count: Int) -> Unit,
    private val onThresholdReached: () -> Unit,
    private var threshold: Int
) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    private var count = 0
    private var lastCountTimeMs = 0L

    fun setThreshold(newThreshold: Int) {
        threshold = newThreshold
    }

    fun start() {
        count = 0
        accelerometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    fun stop() {
        sensorManager.unregisterListener(this)
    }

    fun currentCount(): Int = count

    override fun onSensorChanged(event: SensorEvent) {
        val x = abs(event.values[0])
        val y = abs(event.values[1])
        val z = abs(event.values[2])

        if (x > THRESHOLD_MS2 || y > THRESHOLD_MS2 || z > THRESHOLD_MS2) {
            val now = System.currentTimeMillis()
            if (now - lastCountTimeMs > DEBOUNCE_MS) {
                lastCountTimeMs = now
                count++
                onCountChanged(count)
                if (count >= threshold) {
                    onThresholdReached()
                }
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) { /* 未使用 */ }

    companion object {
        private const val THRESHOLD_MS2 = 70f
        private const val DEBOUNCE_MS = 250L
    }
}
