package com.hanage.alarm.data

/**
 * アラームの解除方法。
 * MATH  : 1桁+1桁の足し算のみで解除
 * SHAKE : 設定回数以上スマホを振ることのみで解除
 * BOTH  : まず計算問題を解き、続けてシェイクも規定回数行わないと解除できない（両方必須）
 */
enum class DismissMode {
    MATH,
    SHAKE,
    BOTH
}
