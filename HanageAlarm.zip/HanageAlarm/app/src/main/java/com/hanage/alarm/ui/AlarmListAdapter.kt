package com.hanage.alarm.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.hanage.alarm.data.Alarm
import com.hanage.alarm.databinding.ItemAlarmBinding
import java.util.Calendar
import java.util.Locale

class AlarmListAdapter(
    private val onClick: (Alarm) -> Unit,
    private val onToggle: (Alarm, Boolean) -> Unit,
    private val onLongClick: (Alarm) -> Unit
) : RecyclerView.Adapter<AlarmListAdapter.VH>() {

    private val items = mutableListOf<Alarm>()

    fun submitList(newItems: List<Alarm>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemAlarmBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(items[position])

    override fun getItemCount(): Int = items.size

    inner class VH(private val binding: ItemAlarmBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(alarm: Alarm) {
            binding.textTime.text = String.format(Locale.getDefault(), "%02d:%02d", alarm.hour, alarm.minute)
            binding.textLabel.text = alarm.label
            binding.textLabel.visibility = if (alarm.label.isBlank()) android.view.View.GONE else android.view.View.VISIBLE
            binding.textDays.text = daysSummary(alarm)

            binding.switchEnabled.setOnCheckedChangeListener(null)
            binding.switchEnabled.isChecked = alarm.enabled
            binding.switchEnabled.setOnCheckedChangeListener { _, checked -> onToggle(alarm, checked) }

            binding.root.setOnClickListener { onClick(alarm) }
            binding.root.setOnLongClickListener { onLongClick(alarm); true }
        }

        private fun daysSummary(alarm: Alarm): String {
            if (!alarm.hasAnyRepeatDay()) return "一回のみ"
            val names = mapOf(
                Calendar.SUNDAY to "日", Calendar.MONDAY to "月", Calendar.TUESDAY to "火",
                Calendar.WEDNESDAY to "水", Calendar.THURSDAY to "木", Calendar.FRIDAY to "金",
                Calendar.SATURDAY to "土"
            )
            return Alarm.daysFromMask(alarm.daysOfWeekMask)
                .sorted()
                .joinToString(" ") { names[it] ?: "" }
        }
    }
}
