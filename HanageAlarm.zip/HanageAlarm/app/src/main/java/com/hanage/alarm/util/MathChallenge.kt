package com.hanage.alarm.util

import kotlin.random.Random

data class MathChallenge(val a: Int, val b: Int) {
    val answer: Int get() = a + b
    val question: String get() = "$a + $b = ?"

    companion object {
        /** 1桁(0〜9) + 1桁(0〜9) の足し算問題を生成する */
        fun generate(): MathChallenge = MathChallenge(Random.nextInt(0, 10), Random.nextInt(0, 10))
    }
}
