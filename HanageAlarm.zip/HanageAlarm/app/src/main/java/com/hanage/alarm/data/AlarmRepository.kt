package com.hanage.alarm.data

import android.content.Context
import kotlinx.coroutines.flow.Flow

class AlarmRepository(context: Context) {
    private val db = AlarmDatabase.getInstance(context)
    private val alarmDao = db.alarmDao()
    private val soundDao = db.customSoundDao()

    fun observeAlarms(): Flow<List<Alarm>> = alarmDao.observeAll()
    fun observeCustomSounds(): Flow<List<CustomSound>> = soundDao.observeAll()

    suspend fun getAllEnabled(): List<Alarm> = alarmDao.getAllEnabled()
    suspend fun getById(id: Long): Alarm? = alarmDao.getById(id)
    suspend fun save(alarm: Alarm): Long = alarmDao.upsert(alarm)
    suspend fun update(alarm: Alarm) = alarmDao.update(alarm)
    suspend fun delete(alarm: Alarm) = alarmDao.delete(alarm)
    suspend fun addCustomSound(sound: CustomSound): Long = soundDao.insert(sound)
}
