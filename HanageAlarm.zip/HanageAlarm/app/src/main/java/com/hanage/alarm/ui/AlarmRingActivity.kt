package com.hanage.alarm.ui

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.hanage.alarm.data.Alarm
import com.hanage.alarm.data.AlarmRepository
import com.hanage.alarm.data.DismissMode
import com.hanage.alarm.databinding.ActivityAlarmRingBinding
import com.hanage.alarm.service.AlarmForegroundService
import com.hanage.alarm.util.AlarmScheduler
import com.hanage.alarm.util.MathChallenge
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * アラーム発動時にロック画面上へ全画面表示される解除画面。
 * 音の再生・音量固定・シェイク検出は AlarmForegroundService 側が担っており、
 * このActivityは「解除条件が満たされたかどうか」を判定してサービスに伝えるUIに徹する。
 */
class AlarmRingActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAlarmRingBinding
    private var alarm: Alarm? = null
    private var currentChallenge: MathChallenge = MathChallenge.generate()

    private val clockHandler = Handler(Looper.getMainLooper())
    private val clockTicker = object : Runnable {
        override fun run() {
            binding.textClock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            clockHandler.postDelayed(this, 1000L)
        }
    }

    private val shakeUpdateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val count = intent.getIntExtra(AlarmForegroundService.EXTRA_SHAKE_COUNT, 0)
            val threshold = intent.getIntExtra(AlarmForegroundService.EXTRA_SHAKE_THRESHOLD, 30)
            binding.textShakeProgress.text = getString(com.hanage.alarm.R.string.ring_shake_progress, count, threshold)
            binding.progressShake.max = threshold
            binding.progressShake.progress = count
        }
    }

    private val finishReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupLockScreenFlags()

        binding = ActivityAlarmRingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSubmitAnswer.setOnClickListener { onSubmitAnswer() }

        val repository = AlarmRepository(applicationContext)
        val alarmId = intent.getLongExtra(AlarmScheduler.EXTRA_ALARM_ID, -1L)
        lifecycleScope.launch {
            alarm = repository.getById(alarmId)
            binding.textLabel.text = alarm?.label.orEmpty()
            renderStage(mathAlreadyCleared = false)
        }
    }

    private fun setupLockScreenFlags() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )
    }

    private fun renderStage(mathAlreadyCleared: Boolean) {
        val currentAlarm = alarm ?: return
        val showMath = when (currentAlarm.dismissMode) {
            DismissMode.MATH -> true
            DismissMode.BOTH -> !mathAlreadyCleared
            DismissMode.SHAKE -> false
        }
        val showShake = when (currentAlarm.dismissMode) {
            DismissMode.SHAKE -> true
            DismissMode.BOTH -> mathAlreadyCleared
            DismissMode.MATH -> false
        }

        binding.mathContainer.visibility = if (showMath) android.view.View.VISIBLE else android.view.View.GONE
        binding.shakeContainer.visibility = if (showShake) android.view.View.VISIBLE else android.view.View.GONE

        if (currentAlarm.dismissMode == DismissMode.BOTH) {
            binding.textStepHint.visibility = android.view.View.VISIBLE
            binding.textStepHint.text = getString(
                if (showMath) com.hanage.alarm.R.string.ring_both_step1 else com.hanage.alarm.R.string.ring_both_step2
            )
        }

        if (showMath) {
            currentChallenge = MathChallenge.generate()
            binding.textQuestion.text = currentChallenge.question
            binding.editAnswer.setText("")
        }
        if (showShake) {
            binding.textShakeProgress.text = getString(com.hanage.alarm.R.string.ring_shake_progress, 0, currentAlarm.shakeThreshold)
            binding.progressShake.max = currentAlarm.shakeThreshold
            binding.progressShake.progress = 0
        }
    }

    private fun onSubmitAnswer() {
        val input = binding.editAnswer.text?.toString()?.trim()
        val value = input?.toIntOrNull()
        if (value != null && value == currentChallenge.answer) {
            startService(AlarmForegroundService.mathSolvedIntent(applicationContext))
            if (alarm?.dismissMode == DismissMode.BOTH) {
                renderStage(mathAlreadyCleared = true)
            }
            // MATH単独モードの場合は service 側が停止処理を行い、finishReceiver 経由で本画面が閉じられる
        } else {
            android.widget.Toast.makeText(this, com.hanage.alarm.R.string.ring_answer_wrong, android.widget.Toast.LENGTH_SHORT).show()
            currentChallenge = MathChallenge.generate()
            binding.textQuestion.text = currentChallenge.question
            binding.editAnswer.setText("")
        }
    }

    override fun onStart() {
        super.onStart()
        registerReceiverCompat(shakeUpdateReceiver, IntentFilter(AlarmForegroundService.ACTION_SHAKE_UPDATE))
        registerReceiverCompat(finishReceiver, IntentFilter(ACTION_FINISH))
        clockHandler.post(clockTicker)
    }

    private fun registerReceiverCompat(receiver: BroadcastReceiver, filter: IntentFilter) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(receiver, filter)
        }
    }

    override fun onStop() {
        super.onStop()
        try { unregisterReceiver(shakeUpdateReceiver) } catch (_: Exception) { }
        try { unregisterReceiver(finishReceiver) } catch (_: Exception) { }
        clockHandler.removeCallbacks(clockTicker)
    }

    // 誤ってバックジェスチャーでアラームを放置できないよう、戻る操作は無効化する
    override fun onBackPressed() { /* 何もしない：解除条件を満たすまで閉じられない */ }

    companion object {
        const val ACTION_FINISH = "com.hanage.alarm.action.RING_FINISH"
    }
}
