package com.hanage.alarm.ui

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.hanage.alarm.R
import com.hanage.alarm.databinding.ActivityOnboardingBinding
import com.hanage.alarm.util.PermissionHelper

private enum class Step { NOTIFICATION, EXACT_ALARM, BATTERY, AUTOSTART, DONE }

class OnboardingActivity : AppCompatActivity() {

    private lateinit var binding: ActivityOnboardingBinding
    private var stepIndex = 0
    private val steps = listOf(Step.NOTIFICATION, Step.EXACT_ALARM, Step.BATTERY, Step.AUTOSTART, Step.DONE)

    private val requestNotificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { advance() }

    private val settingsLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { advance() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOnboardingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSkip.setOnClickListener { advance() }
        renderStep()
    }

    private fun renderStep() {
        // 既に許可済みのステップは自動でスキップする
        while (stepIndex < steps.size - 1 && isAlreadyGranted(steps[stepIndex])) {
            stepIndex++
        }

        val step = steps[stepIndex]
        binding.textStepIndicator.text = "${stepIndex + 1} / ${steps.size}"

        when (step) {
            Step.NOTIFICATION -> {
                binding.textTitle.text = getString(R.string.onboarding_notification_title)
                binding.textDesc.text = getString(R.string.onboarding_notification_desc)
                binding.btnPrimary.text = getString(R.string.btn_next)
                binding.btnPrimary.setOnClickListener {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        requestNotificationPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                    } else advance()
                }
            }
            Step.EXACT_ALARM -> {
                binding.textTitle.text = getString(R.string.onboarding_exact_alarm_title)
                binding.textDesc.text = getString(R.string.onboarding_exact_alarm_desc)
                binding.btnPrimary.text = getString(R.string.btn_open_settings)
                binding.btnPrimary.setOnClickListener {
                    val intent = PermissionHelper.exactAlarmSettingsIntent(this)
                    if (intent != null) settingsLauncher.launch(intent) else advance()
                }
            }
            Step.BATTERY -> {
                binding.textTitle.text = getString(R.string.onboarding_battery_title)
                binding.textDesc.text = getString(R.string.onboarding_battery_desc)
                binding.btnPrimary.text = getString(R.string.btn_open_settings)
                binding.btnPrimary.setOnClickListener {
                    settingsLauncher.launch(PermissionHelper.batteryOptimizationIntent(this))
                }
            }
            Step.AUTOSTART -> {
                binding.textTitle.text = getString(R.string.onboarding_autostart_title)
                binding.textDesc.text = getString(R.string.onboarding_autostart_desc)
                binding.btnPrimary.text = getString(R.string.btn_open_settings)
                binding.btnPrimary.setOnClickListener {
                    settingsLauncher.launch(PermissionHelper.autoStartIntent(this))
                }
            }
            Step.DONE -> {
                binding.textTitle.text = getString(R.string.onboarding_title)
                binding.textDesc.text = ""
                binding.btnSkip.visibility = android.view.View.GONE
                binding.btnPrimary.text = getString(R.string.btn_finish)
                binding.btnPrimary.setOnClickListener { finishOnboarding() }
            }
        }
    }

    private fun isAlreadyGranted(step: Step): Boolean = when (step) {
        Step.NOTIFICATION -> PermissionHelper.hasNotificationPermission(this)
        Step.EXACT_ALARM -> PermissionHelper.hasExactAlarmPermission(this)
        Step.BATTERY -> PermissionHelper.isIgnoringBatteryOptimizations(this)
        Step.AUTOSTART -> false // OS標準の判定方法が無いため常に案内する（ユーザーが「スキップ」可能）
        Step.DONE -> false
    }

    private fun advance() {
        if (stepIndex < steps.size - 1) stepIndex++
        renderStep()
    }

    private fun finishOnboarding() {
        getSharedPreferences(MainActivity.PREFS_NAME, Context.MODE_PRIVATE).edit()
            .putBoolean(MainActivity.KEY_ONBOARDING_DONE, true)
            .apply()
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
