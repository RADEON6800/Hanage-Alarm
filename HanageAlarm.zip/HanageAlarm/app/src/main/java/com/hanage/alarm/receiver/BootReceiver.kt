package com.hanage.alarm.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.hanage.alarm.data.AlarmRepository
import com.hanage.alarm.util.AlarmScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * 端末再起動・アプリ更新後は AlarmManager に登録していた予約が消えるため、
 * DBに保存済みの有効なアラームを読み直して再スケジュールする。
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != Intent.ACTION_MY_PACKAGE_REPLACED &&
            action != "android.intent.action.QUICKBOOT_POWERON"
        ) return

        val pendingResult = goAsync()
        val appContext = context.applicationContext
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val repository = AlarmRepository(appContext)
                val enabledAlarms = repository.getAllEnabled()
                for (alarm in enabledAlarms) {
                    AlarmScheduler.schedule(appContext, alarm)
                }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
