package com.hanage.alarm.util

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.os.Handler
import android.os.Looper

/**
 * アラーム鳴動中、システム音量（アラーム・音楽・着信・通知）を常に最大値に張り付かせる。
 * ユーザーが物理音量キーなどで下げても android.media.VOLUME_CHANGED_ACTION を検知して即座に最大へ戻し、
 * 保険として一定間隔でも再設定する。停止時には鳴動開始前の音量へ復元する。
 */
class VolumeLockManager(private val context: Context) {

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val streams = intArrayOf(
        AudioManager.STREAM_ALARM,
        AudioManager.STREAM_MUSIC,
        AudioManager.STREAM_RING,
        AudioManager.STREAM_NOTIFICATION,
        AudioManager.STREAM_SYSTEM
    )
    private val savedLevels = mutableMapOf<Int, Int>()
    private var locked = false

    private val handler = Handler(Looper.getMainLooper())
    private val reinforceRunnable = object : Runnable {
        override fun run() {
            if (locked) {
                forceMaxVolume()
                handler.postDelayed(this, REINFORCE_INTERVAL_MS)
            }
        }
    }

    private val volumeChangedReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            if (locked) forceMaxVolume()
        }
    }

    fun lock() {
        if (locked) return
        locked = true
        for (stream in streams) {
            try {
                savedLevels[stream] = audioManager.getStreamVolume(stream)
            } catch (_: Exception) { /* 一部端末で取得できないストリームは無視 */ }
        }
        forceMaxVolume()
        context.registerReceiver(volumeChangedReceiver, IntentFilter("android.media.VOLUME_CHANGED_ACTION"))
        handler.postDelayed(reinforceRunnable, REINFORCE_INTERVAL_MS)
    }

    fun unlock() {
        if (!locked) return
        locked = false
        handler.removeCallbacks(reinforceRunnable)
        try {
            context.unregisterReceiver(volumeChangedReceiver)
        } catch (_: Exception) { }
        for ((stream, level) in savedLevels) {
            try {
                audioManager.setStreamVolume(stream, level, 0)
            } catch (_: Exception) { }
        }
        savedLevels.clear()
    }

    private fun forceMaxVolume() {
        for (stream in streams) {
            try {
                val max = audioManager.getStreamMaxVolume(stream)
                audioManager.setStreamVolume(stream, max, 0)
            } catch (_: Exception) { /* Do Not Disturb 等でRING/NOTIFICATIONの変更が拒否される端末がある */ }
        }
    }

    companion object {
        private const val REINFORCE_INTERVAL_MS = 700L
    }
}
