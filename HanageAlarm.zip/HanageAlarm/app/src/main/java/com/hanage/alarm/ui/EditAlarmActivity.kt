package com.hanage.alarm.ui

import android.content.Intent
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.RadioButton
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.chip.Chip
import com.google.android.material.timepicker.MaterialTimePicker
import com.google.android.material.timepicker.TimeFormat
import com.hanage.alarm.R
import com.hanage.alarm.data.Alarm
import com.hanage.alarm.data.AlarmRepository
import com.hanage.alarm.data.CustomSound
import com.hanage.alarm.data.DismissMode
import com.hanage.alarm.databinding.ActivityEditAlarmBinding
import com.hanage.alarm.util.AlarmScheduler
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.Locale

class EditAlarmActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEditAlarmBinding
    private lateinit var repository: AlarmRepository

    private var existingAlarm: Alarm? = null
    private var selectedHour = 7
    private var selectedMinute = 0
    private var selectedSoundUri: String = Alarm.PRESET_DISSONANCE_URI
    private var pendingSelectUri: String? = null

    private val dayChipIds = listOf(
        Calendar.SUNDAY to R.string.day_sun,
        Calendar.MONDAY to R.string.day_mon,
        Calendar.TUESDAY to R.string.day_tue,
        Calendar.WEDNESDAY to R.string.day_wed,
        Calendar.THURSDAY to R.string.day_thu,
        Calendar.FRIDAY to R.string.day_fri,
        Calendar.SATURDAY to R.string.day_sat
    )

    private val openDocumentLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            val name = queryDisplayName(uri) ?: uri.lastPathSegment ?: "カスタム音源"
            lifecycleScope.launch {
                repository.addCustomSound(CustomSound(uri = uri.toString(), displayName = name))
                pendingSelectUri = uri.toString()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditAlarmBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { finish() }

        repository = AlarmRepository(applicationContext)

        buildDayChips()

        binding.sliderShakeThreshold.addOnChangeListener { _, value, _ ->
            binding.textShakeThreshold.text =
                getString(R.string.shake_threshold_label, value.toInt())
        }

        binding.btnTime.setOnClickListener { showTimePicker() }
        binding.btnAddSound.setOnClickListener {
            openDocumentLauncher.launch(arrayOf("audio/*"))
        }
        binding.btnSave.setOnClickListener { save() }

        val alarmId = intent.getLongExtra(EXTRA_ALARM_ID, -1L)
        lifecycleScope.launch {
            if (alarmId != -1L) {
                existingAlarm = repository.getById(alarmId)
            }
            applyInitialState(existingAlarm)
            observeSounds()
        }
    }

    private fun applyInitialState(alarm: Alarm?) {
        val now = Calendar.getInstance()
        selectedHour = alarm?.hour ?: now.get(Calendar.HOUR_OF_DAY)
        selectedMinute = alarm?.minute ?: now.get(Calendar.MINUTE)
        updateTimeButtonText()

        val days = alarm?.let { Alarm.daysFromMask(it.daysOfWeekMask) } ?: emptySet()
        for (i in 0 until binding.chipGroupDays.childCount) {
            val chip = binding.chipGroupDays.getChildAt(i) as Chip
            chip.isChecked = (chip.tag as Int) in days
        }

        when (alarm?.dismissMode ?: DismissMode.MATH) {
            DismissMode.MATH -> binding.radioMath.isChecked = true
            DismissMode.SHAKE -> binding.radioShake.isChecked = true
            DismissMode.BOTH -> binding.radioBoth.isChecked = true
        }

        val threshold = alarm?.shakeThreshold ?: 30
        binding.sliderShakeThreshold.value = threshold.toFloat()
        binding.textShakeThreshold.text = getString(R.string.shake_threshold_label, threshold)

        binding.editLabel.setText(alarm?.label ?: "")
        selectedSoundUri = alarm?.soundUri ?: Alarm.PRESET_DISSONANCE_URI
    }

    private fun updateTimeButtonText() {
        binding.btnTime.text = String.format(Locale.getDefault(), "%02d:%02d", selectedHour, selectedMinute)
    }

    private fun buildDayChips() {
        binding.chipGroupDays.removeAllViews()
        for ((calendarDay, stringRes) in dayChipIds) {
            val chip = Chip(this).apply {
                text = getString(stringRes)
                isCheckable = true
                tag = calendarDay
            }
            binding.chipGroupDays.addView(chip)
        }
    }

    private fun showTimePicker() {
        val picker = MaterialTimePicker.Builder()
            .setTimeFormat(TimeFormat.CLOCK_24H)
            .setHour(selectedHour)
            .setMinute(selectedMinute)
            .build()
        picker.addOnPositiveButtonClickListener {
            selectedHour = picker.hour
            selectedMinute = picker.minute
            updateTimeButtonText()
        }
        picker.show(supportFragmentManager, "time_picker")
    }

    private fun observeSounds() {
        lifecycleScope.launch {
            repository.observeCustomSounds().collect { customSounds ->
                rebuildSoundRadioGroup(customSounds)
            }
        }
    }

    private fun rebuildSoundRadioGroup(customSounds: List<CustomSound>) {
        val group = binding.radioGroupSound
        group.removeAllViews()

        val presetButton = RadioButton(this).apply {
            text = getString(R.string.sound_preset_dissonance)
            tag = Alarm.PRESET_DISSONANCE_URI
        }
        group.addView(presetButton)

        for (sound in customSounds) {
            val rb = RadioButton(this).apply {
                text = sound.displayName
                tag = sound.uri
            }
            group.addView(rb)
        }

        val target = pendingSelectUri ?: selectedSoundUri
        pendingSelectUri = null
        selectedSoundUri = target
        for (i in 0 until group.childCount) {
            val rb = group.getChildAt(i) as RadioButton
            rb.isChecked = (rb.tag == target)
        }
        group.setOnCheckedChangeListener { grp, checkedId ->
            val checked = grp.findViewById<RadioButton>(checkedId)
            selectedSoundUri = checked?.tag as? String ?: Alarm.PRESET_DISSONANCE_URI
        }
    }

    private fun currentDismissMode(): DismissMode = when {
        binding.radioShake.isChecked -> DismissMode.SHAKE
        binding.radioBoth.isChecked -> DismissMode.BOTH
        else -> DismissMode.MATH
    }

    private fun selectedDaysMask(): Int {
        val days = mutableSetOf<Int>()
        for (i in 0 until binding.chipGroupDays.childCount) {
            val chip = binding.chipGroupDays.getChildAt(i) as Chip
            if (chip.isChecked) days.add(chip.tag as Int)
        }
        return Alarm.maskOf(days)
    }

    private fun save() {
        lifecycleScope.launch {
            val alarm = (existingAlarm ?: Alarm(hour = selectedHour, minute = selectedMinute)).copy(
                hour = selectedHour,
                minute = selectedMinute,
                daysOfWeekMask = selectedDaysMask(),
                label = binding.editLabel.text?.toString().orEmpty(),
                dismissMode = currentDismissMode(),
                shakeThreshold = binding.sliderShakeThreshold.value.toInt(),
                soundUri = selectedSoundUri,
                enabled = true
            )
            val newId = repository.save(alarm)
            val saved = if (alarm.id == 0L) alarm.copy(id = newId) else alarm
            AlarmScheduler.schedule(applicationContext, saved)
            finish()
        }
    }

    private fun queryDisplayName(uri: android.net.Uri): String? {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) return cursor.getString(idx)
            }
        }
        return null
    }

    companion object {
        const val EXTRA_ALARM_ID = "extra_alarm_id"
    }
}
